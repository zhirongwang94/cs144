
import * as cookie from 'cookie';

import { Component } from '@angular/core';
import { Post } from './post';
import { POSTS } from './posts';
import { BlogService } from './blog.service'

let cookies = cookie.parse(document.cookie);

function parseJWT(token: string) 
{
    let base64Url = token.split('.')[1];
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(base64));
}


enum AppState { List, Edit, Preview };
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'angular-blog';
  postsToDisplay?: Post[] = POSTS; 

  postToEdit?: Post;

  postToDisplay?: Post = POSTS[0]; 

  appState: number = 0; //previw = 1, edit = 2; 

  username: string = "username_fix_later";
  constructor(private blogService: BlogService) {
    blogService.fetchPosts(this.username).then((posts) => {
      console.log("hello from app constructior");
      console.log("received posts: ");
      console.dir(posts);
      this.postsToDisplay = posts; 
    })
    
  }


  printData(){
    console.log("from app: ");
    console.log("opened post: ");
    console.dir(this.postToEdit);
    console.log("new app: ");
  }

  openPostHandler(post: Post) : void{
    this.postToEdit = post;
    // this.printData();
    this.appState = 1; 
    console.log("Open post: ");
    console.dir(post);
  }

  newPostHandler(): void{
    let post = new Post();
    post.postid = 0; 

    // this.blogService.setPost(this.username, post).then((post) =>{
    //   this.postToEdit = post; 
    //   this.appState = AppState.Edit;

    // });
    this.postToEdit = post; 
    this.appState = AppState.Edit; 
    
    console.log("create a new post here in app ");
    console.log("point the postToEdit to the new created Post");
    this.appState = 1; 
  }

  savePostHandler(post: Post): void{
    console.log("savePostHandler works in app");
    // this.blogService.setPost(this.username, post).then((post) =>{
    //   this.postToEdit = post; 
    //   this.appState = AppState.Edit;
    // });
    // this.appState = 1; 
    console.log("post to save: ");
    console.dir(post);
    this.blogService.setPost(this.username, post).then((post)=>{
      console.log("succeed to save post: ");
      console.dir(post);
      this.appState =  AppState.List; 
    })
    
  }

  deletePostHandler(post: Post): void{
    // console.log("deletePostHandler works in app");
    this.appState = 0; 
    // console.log("delete post: ");
    // console.dir(post);
    this.blogService.deletePost(this.username, this.postToEdit.postid).then(()=>{
      console.log("succeed to delete");
    }
    );
  }


  previewPostHandler(post: Post): void{
    this.postToDisplay = post; 
    this.appState = 2;
    console.log("previewPostHandler works in app");
    console.log( "post:" );
    console.dir(post)
  }

  // previewPostHandler(post: Post): void{
  //   console.log("previewPostHandler works in app");
  //   // this.appState = 0; 
  // }

  editPostHandler(post: Post): void{
    console.log("editPostHandler hello from app");
    this.appState = 1; 
  }
}


// <app-edit [post]="postToEdit" 
//           (savePost)="savePostHandler($event);" 
//           (deletePost)="deletePostHandler($event);" 
//           (previewPost)="previewPostHandler($event);"></app-edit>


// <app-preview [post]="postToDisplay" 
//              (editPost)="editPostHandler($event);">
// </app-preview> 