import { Post } from './post';

// export const POSTS: Post[] = [
//   { id: 11, name: 'Dr Nice' },
//   { id: 12, name: 'Narco' },
//   { id: 13, name: 'Bombasto' },
//   { id: 14, name: 'Celeritas' },
//   { id: 15, name: 'Magneta' },
//   { id: 16, name: 'RubberMan' },
//   { id: 17, name: 'Dynama' },
//   { id: 18, name: 'Dr IQ' },
//   { id: 19, name: 'Magma' },
//   { id: 20, name: 'Tornado' }
// ];


export const POSTS: Post[] = [
{postid: 1,  created: 1518669344517, modified: 1518669344517, title: "## Title 1", body : "Hello, world!" },
{ postid : 1, created : 1518669344517, modified : 1518669344517, title : "## Title 1", body : "Hello, world!" },
{ postid : 2, created : 1518669658420, modified : 1518669658420, title : "## Title 2", body : "I am here." },
{ postid : 1, created : 1518669758320, modified : 1518669758320, title : "## Title 3", body : "today's a nice day" },
{ postid : 2,  created : 1518669758330, modified : 1518669758340, title : "## Title 4", body : "today's a nice day" },
{ postid : 3, created : 1518669758350, modified : 1518669758350, title : "## Title 5", body : "today's a nice day" },
{ postid : 4,  created : 1518669758360, modified : 1518669758360, title : "## Title 6", body : "today's a nice day" },
{ postid : 5,  created : 1518669758370, modified : 1518669758370, title : "## Title 7", body : "gotta do my homework" },
{ postid : 6,   created : 1518669758380, modified : 1518669758380, title : "## Title 8", body : "today's a nice day" },
];