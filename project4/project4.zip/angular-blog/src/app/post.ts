// // export interface Post {
// //     id: number;
// //     name: string;
// //   }

// export interface Post {
//     postid: number ;
//     created: number;
//     modified: number;
//     title: string;
//     body: string;
// };


export class Post {
    postid: number = 0;
    created: number = 0;
    modified: number = 0;
    title: string = "";
    body: string = "";
};